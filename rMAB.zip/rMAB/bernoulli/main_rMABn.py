from experiments import Experiments
from mab import Bandits
import experiments
import mab
import numpy as np
from optparse import OptionParser




lin = False
#lin_t=T means: linear_const
#lin_t=F means: linear
lin_t = True
#lin_const = len(true_prob)
dp = False 
dp_eps = 150


if __name__ == "__main__":
	parser=OptionParser()
	parser.add_option("-d","--dist", action="store", dest="dist", type="string",default="bern", help="the distribution types that arms follow")
	parser.add_option("-s","--syssep", action="store", dest="sys_sep", type="string", default="\\", help="sepration sign of folder")
	parser.add_option("-a","--algo", action="store", dest="algo", type="string", default="ts", help="choose from greedy,ts,t_greedy,ucb")
	parser.add_option("-p","--problist", action="store", dest="true_prob", type="float", default=[0.2,0.5], help="the true probability setting")
	parser.add_option("-t","--samplesize", action="store", dest="sample_size", type="int", default=500, help="the total horizon")
	parser.add_option("-r","--repeats", action="store", dest="repeats", type="int", default=10, help="number of repeated experiments ")
	parser.add_option("-g","--gap", action="store", dest="gap", type="int", default=50, help="gap in output file")
	parser.add_option("-e","--gdeps", action="store", dest="gd_eps", type="float", default=0.1, help="epsilon in greedy algorithm")
	(options, args) = parser.parse_args()
	experiments = Experiments(dist = options.dist, sys_sep = options.sys_sep, algo= options.algo, lin = lin, 
	true_prob = options.true_prob, sample_size = options.sample_size, repeats = options.repeats, gap =  options.gap,
	 gd_eps= options.gd_eps,lin_t=lin_t, lin_const=len(options.true_prob),dp=dp, dp_eps=dp_eps)
	experiments.set_path()
	experiments.total_outputs()

