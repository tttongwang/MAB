from os import path
from mab import Bandits
#import mab
import os
import numpy as np
import pandas as pd
#import scipy.stats as stats
from math import sqrt
from scipy.stats import norm,t

class Experiments():
	def __init__(self, dist, sys_sep, algo, lin,lin_t, lin_const, true_prob, sample_size, repeats, gap, gd_eps,dp, dp_eps):
		self.algo = algo
		self.lin = lin
		self.repeats = repeats
		self.dist = dist
		self.sys_sep = sys_sep
		self.true_prob = true_prob
		self.sample_size = sample_size
		self.gap = gap
		self.bandit_num = len(true_prob)
		self.gd_eps = gd_eps
		self.lin_t = lin_t
		self.lin_const = lin_const
		self.dp = dp
		self.dp_eps = dp_eps

	def set_path(self):
		cwdname = os.getcwd()
		if self.dp:
			folder = cwdname + self.sys_sep + "experiments_"+ self.algo + "_dp" + str(self.dp_eps) + "_" + self.dist
		elif self.lin:
			folder = cwdname + self.sys_sep + "experiments_"+ self.algo + "_linear"+"_" + self.dist
		elif self.lin_t:
			folder = cwdname + self.sys_sep + "experiments_"+ self.algo + "_linear_const"+"_" + self.dist
		else:
			folder = cwdname + self.sys_sep + "experiments_"+ self.algo + "_original"+"_" + self.dist
		
		if path.exists(folder)!= 1:
			os.mkdir(folder)
		self.folder = folder

	def run_experiments(self):
		#for the storage of output of single experiment, which involves the result of each step
		#it is the first output of mab algo 
		mix_dict_bias = dict.fromkeys((range(self.repeats)))
		mix_dict_means = dict.fromkeys((range(self.repeats)))
		mix_dict_pulls = dict.fromkeys((range(self.repeats)))
		mix_dict_cov = dict.fromkeys((range(self.repeats)))
		mix_dict_corr = dict.fromkeys((range(self.repeats)))
		mix_dict_sd = np.zeros((self.repeats,self.bandit_num))
		mix_dict_upper = np.zeros((self.repeats,self.bandit_num))
		mix_dict_lower = np.zeros((self.repeats,self.bandit_num))
		mix_dict_mean2 = np.zeros((self.repeats,self.bandit_num))
		mix_dict_ci_mark = np.zeros((self.repeats,self.bandit_num))
		#two sample t-test pvalue storage
		mix_dict_p_mark1 = np.zeros(self.repeats)
		#one sample t-test pvalue storage
		mix_dict_p_mark2 = np.zeros((self.repeats,self.bandit_num))

		mix_dict_var = np.zeros((self.repeats,self.bandit_num))
		mix_dict_z = np.zeros((self.repeats,self.bandit_num))
		mix_dict_z2 = np.zeros((self.repeats,self.bandit_num))
		mix_dict_t = np.zeros(self.repeats)
		mix_dict_df_upper = np.zeros(self.repeats)
		mix_dict_df_lower = np.zeros(self.repeats)
		mix_dict_df_ci_mark = np.zeros(self.repeats)


		#for the storage of bandit_stats of single experiment, which involves the final result of each arm
		#it is the second output of mab algo 
		mix_dict2 = dict.fromkeys((range(self.repeats)))



		for j in range(self.repeats):
			bandits = Bandits(true_prob=self.true_prob, sample_size=self.sample_size, algo = self.algo, lin = self.lin, gd_eps=self.gd_eps,
					lin_t=self.lin_t, lin_const=self.lin_const, dp= self.dp, dp_eps=self.dp_eps)
			(output_bias, output_means, output_pulls, output_cov, output_corr, bandit_stats, output_reward) = bandits.run()
			#data_ot = pd.DataFrame(output_bias)
			#data_ot.to_csv(self.folder + self.sys_sep + str(self.sample_size) + '_' + str(j) + ".csv")
			mix_dict_bias[j] = output_bias
			mix_dict_means[j] = output_means
			mix_dict_pulls[j] = output_pulls
			mix_dict_cov[j] = output_cov
			mix_dict_corr[j] = output_corr
			mix_dict_sd[j,] = np.nanstd(output_reward,axis=0)
			mix_dict_mean2[j,] = np.nanmean(output_reward, axis=0)
			#mix_dict_lower[j,] = mix_dict_mean2[j,]-1.96*mix_dict_sd[j,]/sqrt(self.sample_size)
			#mix_dict_upper[j,] = mix_dict_mean2[j,]+1.96*mix_dict_sd[j,]/sqrt(self.sample_size)
			mix_dict_var[j,] = np.nanvar(output_reward,axis=0)

			mix_dict2[j] = bandit_stats
			cutoff = 0.05

			for k in range(self.bandit_num):
				mix_dict_lower[j,k] = mix_dict_mean2[j,k] - norm.ppf(1-cutoff/2.0)*mix_dict_sd[j,k]/sqrt(bandit_stats['pulls'][k])
				mix_dict_upper[j,k] = mix_dict_mean2[j,k] + norm.ppf(1-cutoff/2.0)*mix_dict_sd[j,k]/sqrt(bandit_stats['pulls'][k])

				if (mix_dict_lower[j,k] < self.true_prob[k]) and (self.true_prob[k]<mix_dict_upper[j,k]):
					mix_dict_ci_mark[j,k] = 1
				else:
					mix_dict_ci_mark[j,k] = 0

				if mix_dict_sd[j,k] ==0:
					mix_dict_z2[j,k] = float('inf')
					pvalue2 = 0
				else:
					mix_dict_z[j,k] = (bandit_stats["bias"][k])/sqrt(bandit_stats["means"][k]*(1-bandit_stats["means"][k])/bandit_stats['pulls'][k])
					mix_dict_z2[j,k] = (bandit_stats["bias"][k])/mix_dict_sd[j,k]/sqrt(bandit_stats['pulls'][k])
					# calculate one sample t-stat
					pvalue2 = 1 - t.cdf(abs(mix_dict_z2[j,k]),df=bandit_stats['pulls'][k]-1)
				if pvalue2 < cutoff:
					mix_dict_p_mark2[j,k] = 1
				else:
					mix_dict_p_mark2[j,k] = 0

			if self.bandit_num==2:
				#calculate two sample t-stat
				df = self.true_prob[0]-self.true_prob[1]
				if df>=0:
					df_est = mix_dict_mean2[j,0]-mix_dict_mean2[j,1]
				else:
					df_est = mix_dict_mean2[j,1]-mix_dict_mean2[j,0]

				if (mix_dict_sd[j,0]==0) & (mix_dict_sd[j,1]==0):
					mix_dict_t[j] = float('inf')
					pvalue = 0
				else:
					SE = sqrt(mix_dict_sd[j,0]**2/output_pulls[self.sample_size-1][0]+mix_dict_sd[j,1]**2/output_pulls[self.sample_size-1][1])
					t_stat = (df_est-abs(df))/SE
					mix_dict_t[j] = t_stat
					pvalue = 1-t.cdf(abs(t_stat),df=self.sample_size-2)
				if pvalue < cutoff:
					mix_dict_p_mark1[j] = 1
				else:
					mix_dict_p_mark1[j] = 0
				SE = sqrt(mix_dict_sd[j,0]**2/output_pulls[self.sample_size-1][0]+mix_dict_sd[j,1]**2/output_pulls[self.sample_size-1][1])
				mix_dict_df_lower[j] = abs(mix_dict_mean2[j,0]-mix_dict_mean2[j,1]) - t.ppf(1-cutoff/2.0, df=self.sample_size-2)*SE
				mix_dict_df_upper[j] = abs(mix_dict_mean2[j,0]-mix_dict_mean2[j,1]) + t.ppf(1-cutoff/2.0, df=self.sample_size-2)*SE
				if (mix_dict_df_lower[j] < abs(df)) and (abs(df)<mix_dict_df_upper[j]):
					mix_dict_df_ci_mark[j] = 1
				else:
					mix_dict_df_ci_mark[j] = 0


		a=np.array(list(mix_dict2.values()))
		return mix_dict_bias, mix_dict_means, mix_dict_pulls, mix_dict_cov, mix_dict_corr, a, mix_dict_upper, mix_dict_lower, mix_dict_mean2, mix_dict_ci_mark,  mix_dict_p_mark1,mix_dict_p_mark2, mix_dict_var, mix_dict_z, mix_dict_z2, mix_dict_t, mix_dict_df_ci_mark

	def compute_total_stats(self):
		mix_dict_p_mark2 = np.zeros(self.repeats)
		(mix_dict_bias, mix_dict_means, mix_dict_pulls, mix_dict_cov, mix_dict_corr,a, mix_dict_upper, mix_dict_lower, mix_dict_mean2, mix_dict_ci_mark,  mix_dict_p_mark1,mix_dict_p_mark2, mix_dict_var,mix_dict_z, mix_dict_z2, mix_dict_t, mix_dict_df_ci_mark) = self.run_experiments()
		total_stats = np.zeros((self.bandit_num,), dtype=[('true_means',np.float),
    	                                           ('means', np.float),
    	                                           ('bias', np.float),
    	                                           ('total_rewards', np.float),
    	                                           ('pulls', np.float),
    	                                           ('std_means', np.float),
    	                                           ('z_stat', np.float),
    	                                           ('p_value', np.float),
													('covariance', np.float),
													('corr', np.float),
														  ("upper", np.float),
														  ("lower", np.float),
														  ("mean2", np.float),
														  ("ci_prob", np.float),
														  ("ci_prob_df", np.float),
														  ('type1_df', np.float),
														  ('type1_one', np.float),
														  ('var_mean',np.float),
														  ('var_bench', np.float),
														  ('std_bench', np.float),
														  ('std_bias', np.float)])
		total_stats['total_rewards'] = np.mean(a['total_rewards'], axis=0)
		total_stats['pulls'] = np.mean(a['pulls'], axis=0)
		total_stats['means'] = np.mean(a['means'], axis=0)
		total_stats['bias'] = np.mean(a['bias'],axis=0)
		total_stats['std_means'] = np.std(a['means'], axis=0)
		total_stats['covariance'] = np.mean(a['covariance'], axis=0)
		total_stats['corr'] = np.mean(a['corr'], axis=0)
		num1 = np.multiply(self.true_prob,np.subtract(np.ones(self.bandit_num),self.true_prob))
		num2 = np.mean(np.reciprocal(a['pulls']),axis=0)
		total_stats['var_bench'] = np.multiply(num1,num2)
		total_stats['std_bench'] = np.power(total_stats['var_bench'],np.repeat(0.5,self.bandit_num))
		total_stats['std_bias'] = np.subtract(total_stats['std_means'],total_stats['std_bench'])

		#calculte t-stat
		total_stats['z_stat'] = total_stats['bias']/(total_stats['std_means']/sqrt(self.repeats))
		## Compare with the critical t-value
		#Degrees of freedom
		#df = 1*self.repeats - 1
		#p-value after comparison with the t 
		total_stats['p_value'] = norm.cdf(total_stats['z_stat'])
		#total_stats['mse'] = np.mean(a['bias']**2)
		total_stats['true_means'] = self.true_prob
		total_stats['lower'] = np.mean(mix_dict_lower,axis=0)
		total_stats['upper'] = np.mean(mix_dict_upper,axis=0)
		total_stats['mean2'] = np.mean(mix_dict_mean2,axis=0)
		total_stats['ci_prob'] = np.mean(mix_dict_ci_mark, axis=0)
		total_stats['ci_prob_df'] = np.mean(mix_dict_df_ci_mark, axis=0)
		total_stats['type1_df'] = np.mean(mix_dict_p_mark1)
		total_stats['type1_one'] = np.mean(mix_dict_p_mark2, axis=0)
		total_stats['var_mean'] = np.mean(mix_dict_var, axis=0)

		return mix_dict_bias, mix_dict_means, mix_dict_pulls, mix_dict_cov, mix_dict_corr,total_stats, mix_dict_mean2, mix_dict_upper, mix_dict_lower,mix_dict_ci_mark, mix_dict_var,mix_dict_z, mix_dict_z2, mix_dict_t, mix_dict_df_ci_mark


	def total_outputs(self):
		(mix_dict_bias, mix_dict_means, mix_dict_pulls, mix_dict_cov, mix_dict_corr, total_stats, mix_dict_mean2,mix_dict_upper, mix_dict_lower, mix_dict_ci_mark, mix_dict_var,mix_dict_z, mix_dict_z2, mix_dict_t, mix_dict_df_ci_mark) = self.compute_total_stats()
		
		sizelist = range(0, self.sample_size, self.gap)
		##avg_output
		#1st col: avg bias for arm1 sorted by t/gap
		#2nd col: avg bias for arm2 sorted by t/gap
		#...
		#2nd-last col: avg regret sorted by t/gap
		#last col: avg cov sorted by t/gap
		avg_output_bias = np.zeros((len(sizelist), self.bandit_num+1))
		avg_output_cov = np.zeros((len(sizelist), self.bandit_num))
		avg_output_corr = np.zeros((len(sizelist), self.bandit_num))
		avg_output_pulls = np.zeros((len(sizelist), self.bandit_num))
		avg_output_exp_bias = np.zeros((len(sizelist), self.bandit_num))


		s0 = 0
		for s in sizelist:
			#For each size, create #repeats rows in s_mat
			s_bias_mat = np.zeros((self.repeats,self.bandit_num+1))
			s_corr_mat = np.zeros((self.repeats,self.bandit_num))
			s_cov_mat = np.zeros((self.repeats,self.bandit_num))
			s_pulls_mat = np.zeros((self.repeats,self.bandit_num))

			for j in range(self.repeats):
				for k in range(self.bandit_num+1):
					s_bias_mat[j][k] = mix_dict_bias.get(j)[s][k]
				for k in range(self.bandit_num):
					s_corr_mat[j][k] = mix_dict_corr.get(j)[s][k]
					s_cov_mat[j][k] = mix_dict_cov.get(j)[s][k]
					s_pulls_mat[j][k] = mix_dict_pulls.get(j)[s][k]

			avg_output_bias[s0] = np.average(s_bias_mat, axis=0)
			avg_output_cov[s0] = np.average(s_cov_mat, axis=0)
			avg_output_corr[s0] = np.average(s_corr_mat, axis=0)		
			avg_output_pulls[s0] = np.average(s_pulls_mat, axis=0)
			avg_output_exp_bias[s0] = -avg_output_cov[s0]/avg_output_pulls[s0]		
			s0 = s0 + 1


		avg_output_ot_bias = pd.DataFrame(avg_output_bias)
		avg_output_ot_bias.to_csv(self.folder + self.sys_sep + "experiments_bias_regret" + ".csv")
		avg_output_ot_cov = pd.DataFrame(avg_output_cov)
		avg_output_ot_cov.to_csv(self.folder + self.sys_sep + "experiments_cov" + ".csv")
		avg_output_ot_corr = pd.DataFrame(avg_output_corr)
		avg_output_ot_corr.to_csv(self.folder + self.sys_sep + "experiments_corr" + ".csv")
		avg_output_ot_exp_bias = pd.DataFrame(avg_output_exp_bias)
		avg_output_ot_exp_bias.to_csv(self.folder + self.sys_sep + "experiments_exp_bias" + ".csv")
		avg_output_ot_pulls = pd.DataFrame(avg_output_pulls)
		avg_output_ot_pulls.to_csv(self.folder + self.sys_sep + "experiments_pulls" + ".csv")
		avg_output_ot_ci_mark = pd.DataFrame(mix_dict_ci_mark)
		avg_output_ot_ci_mark.to_csv(self.folder + self.sys_sep + "experiments_ci_mark" + ".csv")
		avg_output_ot_lower = pd.DataFrame(mix_dict_lower)
		avg_output_ot_lower.to_csv(self.folder + self.sys_sep + "experiments_lower" + ".csv")
		avg_output_ot_upper = pd.DataFrame(mix_dict_upper)
		avg_output_ot_upper.to_csv(self.folder + self.sys_sep + "experiments_upper" + ".csv")

		avg_output_ot_var = pd.DataFrame(mix_dict_var)
		avg_output_ot_var.to_csv(self.folder + self.sys_sep + "experiments_var" + ".csv")
		avg_output_ot_z = pd.DataFrame(mix_dict_z)
		avg_output_ot_z.to_csv(self.folder + self.sys_sep + "experiments_z" + ".csv")
		avg_output_ot_z2 = pd.DataFrame(mix_dict_z2)
		avg_output_ot_z2.to_csv(self.folder + self.sys_sep + "experiments_t_one" + ".csv")
		avg_output_ot_t = pd.DataFrame(mix_dict_t)
		avg_output_ot_t.to_csv(self.folder + self.sys_sep + "experiments_t_df" + ".csv")


		total_stats_ot = pd.DataFrame(total_stats)
		total_stats_ot.to_csv(self.folder + self.sys_sep + "total" + "_ot" + ".csv")

