# rMAB/rMAB-n algorithms
This is the repository for the rMAB algorithm used in paper "An Optimal Approach in Adaptive Collection Reducing the Bias" by Tong Wang and Zhigen Zhao. 
Details see (archive website)

Code tested on Python 2.7.13. Requires Numpy, Scipy, and Pandas.

Note that for set -s as "\\" in windows system while "/" in linux system. Bernoulli and Normal distributed experiment scenarios are provided, please go to the corresponding folder to run. Algorithms here includes rMAB, rMAB-n, DP methods, and standard MAB. Arguments can be set in command directly, which can be seen in help. 

For usage of main_rMAB.py, run the following:
```
python main_rMAB.py --help 
```

As an example, users can set depending on their requirements, like:
```
python main_rMAB.py -t 500 -r 100 -a "ts" -p [0.2,0.5]
```
